import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"

export const metadata = {
  title: "Terms of Use - Retro Bowl Online",
  description:
    "Our terms of use outline the rules and guidelines for using Retro Bowl Online. Please read these terms carefully before using our website.",
}

export default function TermsOfUsePage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div>
        <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">Terms of Use</h1>

        <div className="prose prose-lg prose-invert max-w-none">
          <p>
            <strong>Last Updated:</strong> May 1, 2023
          </p>

          <p>
            Welcome to Retro Bowl Online. These terms and conditions outline the rules and regulations for the use of
            our website.
          </p>

          <p>
            By accessing this website, we assume you accept these terms and conditions in full. Do not continue to use
            Retro Bowl Online if you do not accept all of the terms and conditions stated on this page.
          </p>

          <h2>1. License to Use Website</h2>
          <p>
            Unless otherwise stated, Retro Bowl Online and/or its licensors own the intellectual property rights for all
            material on Retro Bowl Online. All intellectual property rights are reserved.
          </p>
          <p>
            You may view and/or play games on this website for your own personal use subject to restrictions set in
            these terms and conditions.
          </p>
          <p>You must not:</p>
          <ul>
            <li>Republish material from this website</li>
            <li>Sell, rent or sub-license material from this website</li>
            <li>Reproduce, duplicate or copy material from this website</li>
            <li>
              Redistribute content from Retro Bowl Online (unless content is specifically made for redistribution)
            </li>
          </ul>

          <h2>2. User Content</h2>
          <p>
            In these terms and conditions, "User Content" means material (including without limitation text, images,
            audio material, video material and audio-visual material) that you submit to this website, for whatever
            purpose.
          </p>
          <p>
            You grant to Retro Bowl Online a worldwide, irrevocable, non-exclusive, royalty-free license to use,
            reproduce, adapt, publish, translate and distribute your User Content in any existing or future media. You
            also grant to Retro Bowl Online the right to sub-license these rights, and the right to bring an action for
            infringement of these rights.
          </p>
          <p>
            Your User Content must not be illegal or unlawful, must not infringe any third party's legal rights, and
            must not be capable of giving rise to legal action whether against you or Retro Bowl Online or a third party
            (in each case under any applicable law).
          </p>
          <p>
            You must not submit any User Content to the website that is or has ever been the subject of any threatened
            or actual legal proceedings or other similar complaint.
          </p>
          <p>
            Retro Bowl Online reserves the right to edit or remove any material submitted to this website, or stored on
            our servers, or hosted or published upon this website.
          </p>

          <h2>3. Disclaimer</h2>
          <p>
            To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions
            relating to our website and the use of this website (including, without limitation, any warranties implied
            by law in respect of satisfactory quality, fitness for purpose and/or the use of reasonable care and skill).
          </p>
          <p>Nothing in this disclaimer will:</p>
          <ul>
            <li>Limit or exclude our or your liability for death or personal injury resulting from negligence</li>
            <li>Limit or exclude our or your liability for fraud or fraudulent misrepresentation</li>
            <li>Limit any of our or your liabilities in any way that is not permitted under applicable law</li>
            <li>Exclude any of our or your liabilities that may not be excluded under applicable law</li>
          </ul>
          <p>
            The limitations and exclusions of liability set out in this Section and elsewhere in this disclaimer: (a)
            are subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer or in
            relation to the subject matter of this disclaimer, including liabilities arising in contract, in tort
            (including negligence) and for breach of statutory duty.
          </p>
          <p>
            To the extent that the website and the information and services on the website are provided free of charge,
            we will not be liable for any loss or damage of any nature.
          </p>

          <h2>4. Game Ownership and Copyright</h2>
          <p>
            Retro Bowl is a game developed and owned by New Star Games. Retro Bowl Online is not affiliated with,
            endorsed by, or connected to New Star Games or any official Retro Bowl developers.
          </p>
          <p>
            We do not claim ownership of the Retro Bowl game or its assets. This website is a fan-made platform created
            to provide browser-based access to the game. We encourage users to support the official developers by
            purchasing the full game on mobile app stores or Steam.
          </p>

          <h2>5. External Links</h2>
          <p>
            Our website may contain links to external websites that are not provided or maintained by or in any way
            affiliated with Retro Bowl Online. Please note that we do not guarantee the accuracy, relevance, timeliness,
            or completeness of any information on these external websites.
          </p>

          <h2>6. Advertising</h2>
          <p>
            This website contains advertisements, including those served by Google AdSense. By using this website, you
            agree to view these advertisements as part of the service we provide. We are not responsible for the content
            of these advertisements or any products or services offered by advertisers.
          </p>

          <h2>7. Changes to Terms</h2>
          <p>
            We may revise these terms of use at any time by amending this page. Please check this page regularly to
            ensure you are familiar with the current version, as these terms are binding on you.
          </p>

          <h2>8. Governing Law</h2>
          <p>
            These terms and conditions are governed by and construed in accordance with the laws of the United States,
            and you irrevocably submit to the exclusive jurisdiction of the courts in that location.
          </p>

          <h2>9. Contact Us</h2>
          <p>If you have any questions about these Terms of Use, please contact us:</p>
          <ul>
            <li>By email: support@retrobowlonline.com</li>
            <li>
              By visiting the contact page on our website:{" "}
              <a href="/about" className="text-blue-400 hover:underline">
                Contact Us
              </a>
            </li>
          </ul>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

