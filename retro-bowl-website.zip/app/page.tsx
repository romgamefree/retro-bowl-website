import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"

export default function Home() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <section className="text-center">
        <h1 className="font-pixel text-4xl md:text-5xl lg:text-6xl text-yellow-400 mb-6">
          Play Retro Bowl Online - Free Retro Football Game
        </h1>
        <div className="max-w-2xl mx-auto mb-8">
          <Image
            src="/placeholder.svg?height=300&width=600"
            alt="Retro Bowl gameplay screenshot"
            width={600}
            height={300}
            className="rounded-lg border-4 border-yellow-500 mx-auto"
            priority
          />
        </div>
        <Link href="/play">
          <Button
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white font-pixel text-xl px-8 py-6 rounded-lg border-b-4 border-red-800 hover:border-red-900 transform hover:scale-105 transition-transform"
          >
            PLAY NOW
          </Button>
        </Link>
      </section>

      <section className="mt-12 max-w-3xl mx-auto">
        <h2 className="font-pixel text-2xl text-green-400 mb-4">About Retro Bowl</h2>
        <div className="prose prose-lg prose-invert max-w-none">
          <p>
            Welcome to the ultimate destination to play Retro Bowl online! Retro Bowl is an American football game that
            combines the nostalgic pixel graphics of the 80s and 90s with modern, addictive gameplay mechanics.
            Developed with a love for both retro gaming and American football, this game has quickly become a fan
            favorite among sports gaming enthusiasts.
          </p>
          <p>
            What makes Retro Bowl special is its perfect balance of simplicity and depth. The game features intuitive
            controls that anyone can pick up, yet offers enough strategic elements to keep experienced players engaged
            for hours. As a team manager and quarterback, you'll need to make crucial decisions both on and off the
            field.
          </p>
          <p>
            Our website offers the complete Retro Bowl experience right in your browser - no downloads required! Whether
            you're looking to play a quick game during your lunch break or compete for a spot on our global leaderboard,
            we've got you covered. The game runs smoothly on both desktop and mobile devices, so you can enjoy Retro
            Bowl wherever you go.
          </p>
          <p>
            New to Retro Bowl? Check out our{" "}
            <Link href="/tips" className="text-blue-400 hover:underline">
              comprehensive tips section
            </Link>{" "}
            to learn the basics and advanced strategies. Ready to show off your skills? The{" "}
            <Link href="/leaderboard" className="text-blue-400 hover:underline">
              leaderboard
            </Link>{" "}
            awaits your high scores!
          </p>
        </div>
      </section>

      <section className="mt-12 grid md:grid-cols-2 gap-8">
        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Latest Updates</h2>
          <ul className="space-y-4">
            <li className="border-b border-gray-700 pb-2">
              <span className="text-xs text-gray-400">May 15, 2023</span>
              <p>New defensive strategies added to the Tips section!</p>
            </li>
            <li className="border-b border-gray-700 pb-2">
              <span className="text-xs text-gray-400">April 28, 2023</span>
              <p>Leaderboard now shows player statistics and achievements</p>
            </li>
            <li>
              <span className="text-xs text-gray-400">April 10, 2023</span>
              <p>Mobile controls improved for better gameplay experience</p>
            </li>
          </ul>
        </div>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Community Highlights</h2>
          <div className="space-y-4">
            <div className="border-b border-gray-700 pb-2">
              <p className="font-semibold">RetroChamp2023</p>
              <p className="text-sm">Achieved a perfect season with the Chicago Bears!</p>
            </div>
            <div className="border-b border-gray-700 pb-2">
              <p className="font-semibold">PixelPasser</p>
              <p className="text-sm">Broke the passing yards record with 6,248 yards in a season</p>
            </div>
            <div>
              <p className="font-semibold">FootballLegend</p>
              <p className="text-sm">Won 5 consecutive Retro Bowls with 5 different teams</p>
            </div>
          </div>
        </div>
      </section>

      <FooterBannerAd />
    </div>
  )
}

