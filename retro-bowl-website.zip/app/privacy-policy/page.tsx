import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"

export const metadata = {
  title: "Privacy Policy - Retro Bowl Online",
  description:
    "Our privacy policy explains how we collect, use, and protect your information when you use Retro Bowl Online.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div>
        <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">Privacy Policy</h1>

        <div className="prose prose-lg prose-invert max-w-none">
          <p>
            <strong>Last Updated:</strong> May 1, 2023
          </p>

          <p>
            Welcome to Retro Bowl Online. We respect your privacy and are committed to protecting your personal data.
            This privacy policy will inform you about how we look after your personal data when you visit our website
            and tell you about your privacy rights and how the law protects you.
          </p>

          <h2>1. Important Information and Who We Are</h2>
          <p>
            Retro Bowl Online is a website dedicated to providing access to the Retro Bowl game in a browser
            environment. This privacy policy aims to give you information on how we collect and process your personal
            data through your use of this website.
          </p>
          <p>
            <strong>Contact Details:</strong> If you have any questions about this privacy policy or our privacy
            practices, please contact us at:
          </p>
          <ul>
            <li>Email: support@retrobowlonline.com</li>
          </ul>

          <h2>2. The Data We Collect About You</h2>
          <p>
            We may collect, use, store and transfer different kinds of personal data about you which we have grouped
            together as follows:
          </p>
          <ul>
            <li>
              <strong>Identity Data</strong> includes username or similar identifier.
            </li>
            <li>
              <strong>Contact Data</strong> includes email address (if provided through our contact form).
            </li>
            <li>
              <strong>Technical Data</strong> includes internet protocol (IP) address, browser type and version, time
              zone setting and location, browser plug-in types and versions, operating system and platform, and other
              technology on the devices you use to access this website.
            </li>
            <li>
              <strong>Usage Data</strong> includes information about how you use our website and the Retro Bowl game.
            </li>
            <li>
              <strong>Game Data</strong> includes your game scores, progress, and achievements.
            </li>
          </ul>

          <h2>3. How We Collect Your Personal Data</h2>
          <p>We use different methods to collect data from and about you including through:</p>
          <ul>
            <li>
              <strong>Direct interactions.</strong> You may give us your Identity and Contact Data by filling in forms
              or by corresponding with us by email or otherwise.
            </li>
            <li>
              <strong>Automated technologies or interactions.</strong> As you interact with our website, we may
              automatically collect Technical Data about your equipment, browsing actions and patterns. We collect this
              personal data by using cookies, server logs and other similar technologies.
            </li>
            <li>
              <strong>Game play.</strong> When you play Retro Bowl on our website, we collect Game Data to provide
              features like leaderboards and saved progress.
            </li>
          </ul>

          <h2>4. How We Use Your Personal Data</h2>
          <p>
            We will only use your personal data when the law allows us to. Most commonly, we will use your personal data
            in the following circumstances:
          </p>
          <ul>
            <li>To provide and maintain our service, including to monitor the usage of our website.</li>
            <li>To manage your account and provide game features like leaderboards and saved progress.</li>
            <li>
              To contact you regarding updates or informative communications related to the functionalities of the
              website.
            </li>
            <li>To provide customer support and respond to your inquiries.</li>
            <li>To gather analysis or valuable information so that we can improve our website.</li>
            <li>To detect, prevent and address technical issues.</li>
          </ul>

          <h2>5. Cookies and Tracking Technologies</h2>
          <p>
            We use cookies and similar tracking technologies to track the activity on our website and store certain
            information. Cookies are files with a small amount of data which may include an anonymous unique identifier.
          </p>
          <p>We use the following types of cookies:</p>
          <ul>
            <li>
              <strong>Essential Cookies.</strong> These cookies are necessary for the website to function and cannot be
              switched off in our systems.
            </li>
            <li>
              <strong>Performance Cookies.</strong> These cookies allow us to count visits and traffic sources so we can
              measure and improve the performance of our site.
            </li>
            <li>
              <strong>Functionality Cookies.</strong> These cookies enable the website to provide enhanced functionality
              and personalization.
            </li>
            <li>
              <strong>Targeting Cookies.</strong> These cookies may be set through our site by our advertising partners
              to build a profile of your interests and show you relevant adverts on other sites.
            </li>
          </ul>
          <p>
            You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if
            you do not accept cookies, you may not be able to use some portions of our website.
          </p>

          <h2>6. Advertising</h2>
          <p>
            We use Google AdSense to serve advertisements on our website. Google AdSense may use cookies and web beacons
            to collect data about your visits to this and other websites to provide relevant advertisements about goods
            and services that may interest you.
          </p>
          <p>
            Google's use of advertising cookies enables it and its partners to serve ads based on your visit to our site
            and/or other sites on the Internet. You may opt out of personalized advertising by visiting{" "}
            <a
              href="https://www.google.com/settings/ads"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:underline"
            >
              Google Ads Settings
            </a>
            .
          </p>

          <h2>7. Data Security</h2>
          <p>
            We have put in place appropriate security measures to prevent your personal data from being accidentally
            lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your
            personal data to those employees, agents, contractors and other third parties who have a business need to
            know.
          </p>

          <h2>8. Data Retention</h2>
          <p>
            We will only retain your personal data for as long as necessary to fulfill the purposes we collected it for,
            including for the purposes of satisfying any legal, accounting, or reporting requirements.
          </p>

          <h2>9. Your Legal Rights</h2>
          <p>
            Under certain circumstances, you have rights under data protection laws in relation to your personal data,
            including the right to:
          </p>
          <ul>
            <li>Request access to your personal data.</li>
            <li>Request correction of your personal data.</li>
            <li>Request erasure of your personal data.</li>
            <li>Object to processing of your personal data.</li>
            <li>Request restriction of processing your personal data.</li>
            <li>Request transfer of your personal data.</li>
            <li>Right to withdraw consent.</li>
          </ul>
          <p>If you wish to exercise any of these rights, please contact us at support@retrobowlonline.com.</p>

          <h2>10. Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
            Privacy Policy on this page and updating the "Last Updated" date at the top of this Privacy Policy.
          </p>
          <p>
            You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy
            are effective when they are posted on this page.
          </p>

          <h2>11. Contact Us</h2>
          <p>If you have any questions about this Privacy Policy, you can contact us:</p>
          <ul>
            <li>By email: support@retrobowlonline.com</li>
            <li>
              By visiting the contact page on our website:{" "}
              <a href="/about" className="text-blue-400 hover:underline">
                Contact Us
              </a>
            </li>
          </ul>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

