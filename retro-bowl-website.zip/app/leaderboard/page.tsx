import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export const metadata = {
  title: "Retro Bowl Leaderboard - Top Players Worldwide",
  description:
    "Check out the top Retro Bowl players from around the world. See high scores, championship wins, and other achievements on our global leaderboard.",
}

// Mock leaderboard data
const leaderboardData = [
  { rank: 1, username: "RetroChamp", score: 1250, championships: 8, winPercentage: "92%", longestWinStreak: 24 },
  { rank: 2, username: "FootballLegend", score: 1180, championships: 7, winPercentage: "89%", longestWinStreak: 21 },
  { rank: 3, username: "PixelPasser", score: 1120, championships: 6, winPercentage: "87%", longestWinStreak: 19 },
  { rank: 4, username: "GridironGuru", score: 1050, championships: 6, winPercentage: "85%", longestWinStreak: 17 },
  { rank: 5, username: "TouchdownKing", score: 980, championships: 5, winPercentage: "83%", longestWinStreak: 16 },
  { rank: 6, username: "BowlWinner", score: 920, championships: 5, winPercentage: "81%", longestWinStreak: 15 },
  { rank: 7, username: "FieldGeneral", score: 870, championships: 4, winPercentage: "79%", longestWinStreak: 14 },
  { rank: 8, username: "RetroRunner", score: 830, championships: 4, winPercentage: "77%", longestWinStreak: 13 },
  { rank: 9, username: "PixelCoach", score: 790, championships: 3, winPercentage: "75%", longestWinStreak: 12 },
  { rank: 10, username: "EndZoneHero", score: 750, championships: 3, winPercentage: "73%", longestWinStreak: 11 },
]

export default function LeaderboardPage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div>
        <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">
          Retro Bowl Leaderboard - Top Players Worldwide
        </h1>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 mb-8">
          <p className="mb-4">
            Our global leaderboard showcases the best Retro Bowl players from around the world. Can you make it to the
            top? Play now and submit your scores to see where you rank!
          </p>
          <p>Leaderboard updates daily. Scores are verified to ensure fair competition.</p>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-800 border-b border-gray-700">
                <TableHead className="font-pixel text-yellow-400">Rank</TableHead>
                <TableHead className="font-pixel text-yellow-400">Player</TableHead>
                <TableHead className="font-pixel text-yellow-400">Score</TableHead>
                <TableHead className="font-pixel text-yellow-400">Championships</TableHead>
                <TableHead className="font-pixel text-yellow-400">Win %</TableHead>
                <TableHead className="font-pixel text-yellow-400">Longest Streak</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leaderboardData.map((player) => (
                <TableRow key={player.rank} className="border-b border-gray-700 hover:bg-gray-800/50">
                  <TableCell className="font-medium">
                    {player.rank <= 3 ? (
                      <span
                        className={`inline-block px-2 py-1 rounded ${
                          player.rank === 1 ? "bg-yellow-500" : player.rank === 2 ? "bg-gray-400" : "bg-amber-700"
                        } text-black font-bold`}
                      >
                        {player.rank}
                      </span>
                    ) : (
                      player.rank
                    )}
                  </TableCell>
                  <TableCell>{player.username}</TableCell>
                  <TableCell>{player.score}</TableCell>
                  <TableCell>{player.championships}</TableCell>
                  <TableCell>{player.winPercentage}</TableCell>
                  <TableCell>{player.longestWinStreak}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
            <h2 className="font-pixel text-xl text-green-400 mb-4">Monthly Champions</h2>
            <div className="space-y-4">
              <div className="flex justify-between border-b border-gray-700 pb-2">
                <span>April 2023</span>
                <span className="font-semibold">RetroChamp</span>
              </div>
              <div className="flex justify-between border-b border-gray-700 pb-2">
                <span>March 2023</span>
                <span className="font-semibold">FootballLegend</span>
              </div>
              <div className="flex justify-between border-b border-gray-700 pb-2">
                <span>February 2023</span>
                <span className="font-semibold">PixelPasser</span>
              </div>
              <div className="flex justify-between">
                <span>January 2023</span>
                <span className="font-semibold">GridironGuru</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
            <h2 className="font-pixel text-xl text-green-400 mb-4">Notable Achievements</h2>
            <div className="space-y-4">
              <div className="border-b border-gray-700 pb-2">
                <p className="font-semibold">Most Championships</p>
                <p className="text-sm">RetroChamp (8 championships)</p>
              </div>
              <div className="border-b border-gray-700 pb-2">
                <p className="font-semibold">Longest Win Streak</p>
                <p className="text-sm">RetroChamp (24 games)</p>
              </div>
              <div className="border-b border-gray-700 pb-2">
                <p className="font-semibold">Highest Single Game Score</p>
                <p className="text-sm">PixelPasser (76 points)</p>
              </div>
              <div>
                <p className="font-semibold">Most Passing Yards (Season)</p>
                <p className="text-sm">PixelPasser (6,248 yards)</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

