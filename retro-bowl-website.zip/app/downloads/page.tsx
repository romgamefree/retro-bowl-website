import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"
import { Button } from "@/components/ui/button"
import { Apple, SmartphoneIcon as Android, Globe } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Download Retro Bowl Offline",
  description:
    "Download Retro Bowl to play offline on your mobile device or computer. Get the official app from trusted sources and enjoy the game anywhere.",
}

export default function DownloadsPage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div>
        <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">Download Retro Bowl Offline</h1>

        <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 mb-8">
          <p className="mb-4">
            While you can play Retro Bowl directly in your browser on our website, you may also want to download the
            official app to play offline. Below are links to download Retro Bowl from official sources.
          </p>
          <p>
            Please note that we are not affiliated with the official Retro Bowl developers. These links direct you to
            the official app stores where you can download the game.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 text-center">
            <Apple className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <h2 className="font-pixel text-xl text-green-400 mb-4">iOS App Store</h2>
            <p className="mb-6 text-sm">
              Download Retro Bowl for your iPhone or iPad. Play on the go and sync your progress across devices.
            </p>
            <Link href="https://apps.apple.com/app/retro-bowl/id1478902583" target="_blank" rel="noopener noreferrer">
              <Button className="bg-blue-600 hover:bg-blue-700 w-full">Download for iOS</Button>
            </Link>
          </div>

          <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 text-center">
            <Android className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <h2 className="font-pixel text-xl text-green-400 mb-4">Google Play</h2>
            <p className="mb-6 text-sm">
              Get Retro Bowl on your Android device. Enjoy the full game experience with all features unlocked.
            </p>
            <Link
              href="https://play.google.com/store/apps/details?id=com.newstargames.retrobowl"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-green-600 hover:bg-green-700 w-full">Download for Android</Button>
            </Link>
          </div>

          <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 text-center">
            <Globe className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <h2 className="font-pixel text-xl text-green-400 mb-4">Steam</h2>
            <p className="mb-6 text-sm">
              Play Retro Bowl on your PC or Mac through Steam. Experience the game with keyboard controls and larger
              screen.
            </p>
            <Link
              href="https://store.steampowered.com/app/1620560/Retro_Bowl/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-gray-600 hover:bg-gray-700 w-full">Download on Steam</Button>
            </Link>
          </div>
        </div>

        <div className="mt-8 bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="font-pixel text-xl text-green-400 mb-4">System Requirements</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-yellow-400 mb-2">iOS</h3>
              <ul className="space-y-2 text-sm">
                <li>iOS 11.0 or later</li>
                <li>Compatible with iPhone, iPad, and iPod touch</li>
                <li>~100MB free space</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-yellow-400 mb-2">Android</h3>
              <ul className="space-y-2 text-sm">
                <li>Android 5.0 or later</li>
                <li>~80MB free space</li>
                <li>Any screen resolution supported</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-yellow-400 mb-2">PC/Mac (Steam)</h3>
              <ul className="space-y-2 text-sm">
                <li>Windows 7 or later / macOS 10.12 or later</li>
                <li>1GB RAM</li>
                <li>~200MB free space</li>
                <li>Any graphics card with DirectX 9 support</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-gray-800 p-6 rounded-lg border border-gray-700">
          <h2 className="font-pixel text-xl text-green-400 mb-4">Frequently Asked Questions</h2>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-yellow-400 mb-1">Is Retro Bowl free to download?</h3>
              <p className="text-sm">
                Retro Bowl is free to download with optional in-app purchases. The full game can be unlocked with a
                one-time purchase.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-yellow-400 mb-1">Can I transfer my progress between devices?</h3>
              <p className="text-sm">
                Yes, if you use the same account (Apple ID, Google Play, or Steam) across devices, your progress will
                sync automatically.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-yellow-400 mb-1">Is an internet connection required to play?</h3>
              <p className="text-sm">
                Once downloaded, Retro Bowl can be played offline. However, features like leaderboards require an
                internet connection.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-yellow-400 mb-1">How does the browser version compare to the app?</h3>
              <p className="text-sm">
                The browser version offers the core gameplay experience, while the downloadable app includes additional
                features and offline play.
              </p>
            </div>
          </div>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

