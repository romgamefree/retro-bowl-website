import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"
import SidebarAd from "@/components/ads/sidebar-ad"
import Image from "next/image"
import Link from "next/link"

export const metadata = {
  title: "About Retro Bowl Online",
  description:
    "Learn about Retro Bowl Online, our mission to provide free access to this popular retro football game, and the team behind the website.",
}

export default function AboutPage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:flex-grow">
          <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">About Retro Bowl Online</h1>

          <div className="prose prose-lg prose-invert max-w-none">
            <h2>Our Mission</h2>
            <p>
              Welcome to Retro Bowl Online, the premier destination for playing the popular retro-style American
              football game right in your browser. Our mission is to provide free, accessible gameplay to fans of retro
              sports games worldwide, while creating a community where players can share strategies, compete on
              leaderboards, and connect with fellow enthusiasts.
            </p>

            <p>
              We believe that great games should be accessible to everyone, which is why we've created this platform to
              let you enjoy Retro Bowl without downloads, installations, or complicated setups. Just visit our site,
              click play, and you're immediately in the game!
            </p>

            <div className="flex justify-center my-6">
              <Image
                src="/placeholder.svg?height=200&width=400"
                alt="Retro Bowl Online team"
                width={400}
                height={200}
                className="rounded-lg border-2 border-gray-700"
              />
            </div>

            <h2>The Game</h2>
            <p>
              Retro Bowl is a pixel-art American football game that captures the essence of both retro gaming and the
              excitement of football. With its simple yet deep gameplay, it allows players to experience the thrill of
              managing a football team and executing plays on the field.
            </p>

            <p>
              <strong>Important Disclaimer:</strong> We are not affiliated with the official Retro Bowl developers. This
              website is a fan-made platform created to celebrate and share the game. The original game was developed by
              New Star Games, and we encourage supporting the official developers by purchasing the full game on mobile
              app stores or Steam.
            </p>

            <SidebarAd />

            <h2>Our Team</h2>
            <p>
              Retro Bowl Online was created by a small team of passionate gamers and web developers who share a love for
              retro-style sports games. We're constantly working to improve the site, add new features, and ensure the
              best possible gaming experience.
            </p>

            <p>Our team consists of:</p>
            <ul>
              <li>
                <strong>Game Integration Specialists</strong> who ensure the game runs smoothly in browsers
              </li>
              <li>
                <strong>Web Developers</strong> who build and maintain the website
              </li>
              <li>
                <strong>Content Writers</strong> who create guides, tips, and news
              </li>
              <li>
                <strong>Community Managers</strong> who engage with our player base
              </li>
            </ul>

            <h2>Community Values</h2>
            <p>At Retro Bowl Online, we value:</p>
            <ul>
              <li>
                <strong>Accessibility</strong> - Making gaming available to everyone
              </li>
              <li>
                <strong>Community</strong> - Creating a positive environment for players to connect
              </li>
              <li>
                <strong>Quality</strong> - Providing the best possible gaming experience
              </li>
              <li>
                <strong>Transparency</strong> - Being open about our operations and limitations
              </li>
            </ul>

            <h2>Contact Us</h2>
            <p>
              Have questions, suggestions, or feedback? We'd love to hear from you! You can reach our team at{" "}
              <a href="mailto:support@retrobowlonline.com" className="text-blue-400 hover:underline">
                support@retrobowlonline.com
              </a>{" "}
              or use the contact form below.
            </p>

            <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 my-6">
              <h3 className="text-xl font-semibold mb-4">Contact Form</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
                      placeholder="Your email"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    placeholder="Subject"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-1">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-yellow-500 text-black font-medium rounded-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                >
                  Send Message
                </button>
              </form>
            </div>

            <h2>Support This Site</h2>
            <p>
              Retro Bowl Online is free to use, but maintaining and improving the site requires resources. If you enjoy
              our platform, consider supporting us by:
            </p>
            <ul>
              <li>Sharing the site with friends and on social media</li>
              <li>Disabling ad blockers on our site</li>
              <li>Providing feedback to help us improve</li>
              <li>Contributing to our community by sharing tips and strategies</li>
            </ul>

            <p>Thank you for being part of the Retro Bowl Online community!</p>
          </div>
        </div>

        <div className="lg:w-80">
          <SidebarAd />

          <div className="mt-6 bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="font-pixel text-lg text-yellow-400 mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/privacy-policy" className="hover:text-yellow-400">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms-of-use" className="hover:text-yellow-400">
                  Terms of Use
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-yellow-400">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/sitemap" className="hover:text-yellow-400">
                  Sitemap
                </Link>
              </li>
            </ul>
          </div>

          <div className="mt-6 bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="font-pixel text-lg text-yellow-400 mb-3">Follow Us</h3>
            <div className="flex space-x-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-blue-400"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-blue-600"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-pink-500"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-red-600"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                  <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

