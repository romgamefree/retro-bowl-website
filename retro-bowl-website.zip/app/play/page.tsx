import HeaderBannerAd from "@/components/ads/header-banner-ad"
import FooterBannerAd from "@/components/ads/footer-banner-ad"
import SidebarAd from "@/components/ads/sidebar-ad"

export const metadata = {
  title: "Play Retro Bowl - Free Online Football Game",
  description:
    "Play Retro Bowl right in your browser! No downloads needed. Experience the thrill of retro-style American football with simple controls and addictive gameplay.",
}

export default function PlayPage() {
  return (
    <div className="space-y-8">
      <HeaderBannerAd />

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:flex-grow">
          <h1 className="font-pixel text-3xl md:text-4xl text-yellow-400 mb-6">Play Retro Bowl Online</h1>

          <div className="bg-gray-800 p-4 rounded-lg border-4 border-yellow-500 aspect-video relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="font-pixel text-xl text-center">
                Game would be embedded here
                <br />
                <span className="text-sm block mt-2">(Actual game implementation would go here)</span>
              </p>
            </div>
          </div>

          <div className="mt-8 bg-gray-800 p-6 rounded-lg border border-gray-700">
            <h2 className="font-pixel text-xl text-green-400 mb-4">Game Controls</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold text-yellow-400 mb-2">Offense</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <span className="text-gray-400">Pass:</span> Tap and drag to aim, release to throw
                  </li>
                  <li>
                    <span className="text-gray-400">Run:</span> Tap the running back and use directional controls
                  </li>
                  <li>
                    <span className="text-gray-400">Dive:</span> Tap the player while running
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-yellow-400 mb-2">Defense</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <span className="text-gray-400">Switch player:</span> Tap the player you want to control
                  </li>
                  <li>
                    <span className="text-gray-400">Tackle:</span> Get close to the ball carrier
                  </li>
                  <li>
                    <span className="text-gray-400">Intercept:</span> Position your player in the passing lane
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:w-80">
          <SidebarAd />

          <div className="mt-6 bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="font-pixel text-lg text-yellow-400 mb-3">Quick Tips</h3>
            <ul className="space-y-2 text-sm">
              <li>Use short passes to consistently move the chains</li>
              <li>Save your timeouts for the end of each half</li>
              <li>Upgrade your defense to win championships</li>
              <li>Balance your salary cap carefully</li>
              <li>Draft young players with high potential</li>
            </ul>
          </div>

          <div className="mt-6 bg-gray-800 p-4 rounded-lg border border-gray-700">
            <h3 className="font-pixel text-lg text-yellow-400 mb-3">Your Stats</h3>
            <div className="space-y-2 text-sm">
              <p>
                <span className="text-gray-400">Games Played:</span> 0
              </p>
              <p>
                <span className="text-gray-400">Wins:</span> 0
              </p>
              <p>
                <span className="text-gray-400">Championships:</span> 0
              </p>
              <p>
                <span className="text-gray-400">Best Season:</span> N/A
              </p>
              <p>
                <span className="text-gray-400">High Score:</span> 0
              </p>
            </div>
          </div>
        </div>
      </div>

      <FooterBannerAd />
    </div>
  )
}

