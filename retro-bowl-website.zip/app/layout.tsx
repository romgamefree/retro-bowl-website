import type React from "react"
import type { Metadata } from "next/dist/lib/metadata/types/metadata-interface"
import { Inter, Press_Start_2P } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import AdSenseScript from "@/components/adsense-script"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const pressStart2P = Press_Start_2P({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-press-start",
})

export const metadata: Metadata = {
  title: {
    default: "Play Retro Bowl Online | Free Retro Football Game",
    template: "%s | Retro Bowl Online",
  },
  description:
    "Play Retro Bowl online for free! Enjoy this retro football game with no downloads required - fun, fast, and unblocked.",
  keywords: [
    "retro bowl",
    "retro football game",
    "play retro bowl online",
    "retro bowl unblocked",
    "free football game",
  ],
  authors: [{ name: "Retro Bowl Online" }],
  creator: "Retro Bowl Online",
  publisher: "Retro Bowl Online",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} ${pressStart2P.variable} font-sans bg-gray-900 text-white min-h-screen flex flex-col`}
      >
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8">{children}</main>
        <Footer />
        <AdSenseScript />
      </body>
    </html>
  )
}



import './globals.css'