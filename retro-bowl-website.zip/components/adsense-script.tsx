"use client"

export default function AdSenseScript() {
  // This component only loads the AdSense script
  // It doesn't initialize any ads to avoid the "already have ads in them" error
  return (
    <>
      {/* This script tag would be replaced with actual AdSense script once approved */}
      <script
        async
        src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-xxx"
        crossOrigin="anonymous"
      ></script>
    </>
  )
}

