"use client"

import { useEffect, useRef } from "react"

export default function FooterBannerAd() {
  const adRef = useRef<HTMLModElement>(null)

  useEffect(() => {
    try {
      // Only initialize this specific ad slot
      if (adRef.current && typeof window !== "undefined") {
        ;(window.adsbygoogle = window.adsbygoogle || []).push({})
      }
    } catch (error) {
      console.error("AdSense error:", error)
    }
  }, [])

  return (
    <div className="text-center my-4">
      <ins
        ref={adRef}
        className="adsbygoogle"
        style={{ display: "inline-block", width: "728px", height: "90px" }}
        data-ad-client="ca-pub-xxx"
        data-ad-slot="xxx"
      >
        <div className="w-full h-full bg-gray-800 rounded-md border border-gray-700 flex items-center justify-center">
          <div className="text-sm text-gray-400">
            <span className="block">Advertisement</span>
            <span className="text-xs">(728x90 Banner Ad)</span>
          </div>
        </div>
      </ins>
    </div>
  )
}

