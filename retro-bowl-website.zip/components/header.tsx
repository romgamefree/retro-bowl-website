import Link from "next/link"
import { Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-800 bg-gray-900/95 backdrop-blur supports-[backdrop-filter]:bg-gray-900/75">
      <div className="container flex h-16 items-center px-4">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <div className="font-pixel text-xl text-yellow-400">RETRO BOWL</div>
        </Link>
        <div className="hidden md:flex md:flex-1">
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link href="/" className="transition-colors hover:text-yellow-400">
              Home
            </Link>
            <Link href="/play" className="transition-colors hover:text-yellow-400">
              Play
            </Link>
            <Link href="/tips" className="transition-colors hover:text-yellow-400">
              Tips
            </Link>
            <Link href="/leaderboard" className="transition-colors hover:text-yellow-400">
              Leaderboard
            </Link>
            <Link href="/downloads" className="transition-colors hover:text-yellow-400">
              Downloads
            </Link>
            <Link href="/about" className="transition-colors hover:text-yellow-400">
              About
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <Link href="/play" className="hidden md:block">
            <Button className="bg-red-600 hover:bg-red-700 text-white font-pixel rounded-lg border-b-2 border-red-800 hover:border-red-900">
              PLAY NOW
            </Button>
          </Link>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-gray-900 text-white">
              <nav className="flex flex-col gap-4 mt-8">
                <Link href="/" className="text-lg font-medium hover:text-yellow-400">
                  Home
                </Link>
                <Link href="/play" className="text-lg font-medium hover:text-yellow-400">
                  Play
                </Link>
                <Link href="/tips" className="text-lg font-medium hover:text-yellow-400">
                  Tips
                </Link>
                <Link href="/leaderboard" className="text-lg font-medium hover:text-yellow-400">
                  Leaderboard
                </Link>
                <Link href="/downloads" className="text-lg font-medium hover:text-yellow-400">
                  Downloads
                </Link>
                <Link href="/about" className="text-lg font-medium hover:text-yellow-400">
                  About
                </Link>
                <Link href="/privacy-policy" className="text-lg font-medium hover:text-yellow-400">
                  Privacy Policy
                </Link>
                <Link href="/terms-of-use" className="text-lg font-medium hover:text-yellow-400">
                  Terms of Use
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

