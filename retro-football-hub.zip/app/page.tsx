import Image from "next/image"
import Link from "next/link"
import GameCard from "@/components/game-card"
import InContentAd from "@/components/in-content-ad"
import SeoText from "@/components/seo-text"
import RelatedGames from "@/components/related-games"

export default function Home() {
  const games = [
    {
      title: "Retro Bowl",
      slug: "retro-bowl",
      description: "The classic retro-styled American football game that combines simple gameplay with deep strategy.",
      imageUrl: "/game-retro-bowl.jpg",
      altText: "Retro Bowl gameplay screenshot",
    },
    {
      title: "Retro Bowl 2",
      slug: "retro-bowl-2",
      description: "The sequel to the hit game with enhanced graphics, more teams, and expanded gameplay options.",
      imageUrl: "/game-retro-bowl-2.jpg",
      altText: "Retro Bowl 2 gameplay screenshot",
    },
    {
      title: "Retro Bowl 25",
      slug: "retro-bowl-25",
      description: "The latest edition with updated rosters, new stadiums, and improved game mechanics.",
      imageUrl: "/game-retro-bowl-25.jpg",
      altText: "Retro Bowl 25 gameplay screenshot",
    },
    {
      title: "Retro Football",
      slug: "retro-football",
      description: "A pixel-perfect football experience with arcade-style gameplay and retro aesthetics.",
      imageUrl: "/game-retro-football.jpg",
      altText: "Retro Football pixel art",
    },
  ]

  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-900 to-blue-700 py-12 text-white md:py-16">
        <div className="absolute inset-0 opacity-20">
          <Image src="/hero-pattern.jpg" alt="Background pattern" fill className="object-cover" priority />
        </div>
        <div className="container-custom relative z-10">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-4 text-3xl font-bold md:text-4xl lg:text-5xl">
              Play Retro Bowl & More - Free Retro Football Games Online
            </h1>
            <p className="mb-6 text-base md:text-lg">
              Experience the thrill of retro-styled football games right in your browser. No downloads needed - just
              pure gaming fun!
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/play/retro-bowl" className="btn btn-primary btn-lg">
                Play Retro Bowl Now
              </Link>
              <Link href="/tips" className="btn btn-secondary btn-lg">
                View Game Tips
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="section-title">Featured Games</h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {games.map((game) => (
              <GameCard
                key={game.slug}
                title={game.title}
                slug={game.slug}
                description={game.description}
                imageUrl={game.imageUrl}
                altText={game.altText}
              />
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section bg-gray-50">
        <div className="container-custom">
          <div className="mx-auto max-w-3xl">
            <h2 className="section-title">About Our Retro Football Games</h2>

            <SeoText>
              <p className="mb-4">
                Welcome to RetroFootballHub, your ultimate destination for nostalgic football gaming! Our collection of
                retro-styled football games brings back the simple joy of classic gaming while offering deep strategic
                gameplay that keeps you coming back for more.
              </p>

              <InContentAd />

              <p className="mb-4">
                Retro Bowl has captured the hearts of gamers worldwide with its perfect blend of simple controls and
                deep team management. The pixelated graphics harken back to the golden age of gaming, while the gameplay
                mechanics offer a surprisingly rich football experience. Whether you're drafting players, managing your
                salary cap, or calling plays on the field, Retro Bowl delivers hours of entertainment.
              </p>

              <p className="mb-4">
                But that's just the beginning! Retro Bowl 2 expands on the original with enhanced graphics that maintain
                that beloved pixel art style while adding more detail and character. The sequel introduces more teams,
                expanded league options, and refined gameplay that addresses fan feedback while staying true to what
                made the original great.
              </p>

              <p className="mb-4">
                For those looking for the most up-to-date experience, Retro Bowl 25 offers the latest rosters, new
                stadiums, and improved game mechanics. The developers have carefully balanced tradition with innovation,
                ensuring that longtime fans and newcomers alike will find something to love.
              </p>

              <p className="mb-4">
                And don't miss Retro Football, which takes a slightly different approach with its arcade-style gameplay.
                It's perfect for quick sessions when you just want to jump in and score some touchdowns without worrying
                about season management.
              </p>

              <p className="mb-4">
                What makes these games special isn't just their charming visuals or accessible gameplay—it's the way
                they capture the essence of football while stripping away unnecessary complexity. They remind us that
                great games don't need cutting-edge graphics or complicated controls to be deeply engaging.
              </p>

              <p>
                So whether you're reliving the glory days of 8-bit gaming or discovering retro-styled games for the
                first time, RetroFootballHub is your home for pixel-perfect football action. Jump in and play today—no
                downloads required!
              </p>
            </SeoText>
          </div>
        </div>
      </section>

      {/* Quick Tips Section */}
      <section className="section bg-white">
        <div className="container-custom">
          <div className="mx-auto max-w-3xl">
            <h2 className="section-title">Quick Tips for Beginners</h2>

            <div className="mb-6 rounded-lg bg-gray-50 p-6 shadow-md">
              <h3 className="mb-4 text-xl font-bold">Getting Started in Retro Bowl</h3>
              <ul className="list-disc space-y-2 pl-5">
                <li>Focus on quarterback and receiver upgrades first</li>
                <li>Use the dive button near the end zone to avoid fumbles</li>
                <li>Don't neglect your defense - cornerbacks are especially valuable</li>
                <li>Save your coaching credits for key player upgrades</li>
                <li>Practice the passing mechanics in training mode</li>
              </ul>
            </div>

            <div className="text-center">
              <Link href="/tips" className="btn btn-primary">
                View All Tips & Strategies
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Community Highlights */}
      <section className="section bg-gray-50">
        <div className="container-custom">
          <h2 className="section-title">Community Highlights</h2>

          <div className="mx-auto grid max-w-4xl grid-cols-1 gap-8 md:grid-cols-2">
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h3 className="mb-3 text-lg font-bold">Top Achievement</h3>
              <p className="mb-2 text-sm">
                <span className="font-bold">Player:</span> RetroChamp88
              </p>
              <p className="mb-2 text-sm">
                <span className="font-bold">Game:</span> Retro Bowl
              </p>
              <p className="mb-4 text-sm">
                <span className="font-bold">Achievement:</span> 15 consecutive championship wins
              </p>
              <Link href="/community" className="text-primary hover:underline">
                Join the discussion →
              </Link>
            </div>

            <div className="rounded-lg bg-white p-6 shadow-md">
              <h3 className="mb-3 text-lg font-bold">Strategy of the Month</h3>
              <p className="mb-2 text-sm">
                <span className="font-bold">Contributor:</span> FootballWizard
              </p>
              <p className="mb-2 text-sm">
                <span className="font-bold">Game:</span> Retro Bowl 2
              </p>
              <p className="mb-4 text-sm">
                <span className="font-bold">Strategy:</span> "The Perfect Defense" formation guide
              </p>
              <Link href="/community" className="text-primary hover:underline">
                Read more →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Related Games */}
      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="section-title">Explore More Games</h2>
          <RelatedGames title="Popular Football Games" />
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-10 text-white">
        <div className="container-custom text-center">
          <h2 className="mb-4 text-2xl font-bold">Ready to Play?</h2>
          <p className="mx-auto mb-6 max-w-2xl text-base">
            Jump into the action now and experience the fun of retro football gaming!
          </p>
          <Link href="/play/retro-bowl" className="btn bg-white px-6 py-2 text-primary hover:bg-gray-100">
            Play Retro Bowl Now
          </Link>
        </div>
      </section>
    </>
  )
}

