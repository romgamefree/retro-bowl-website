import InContentAd from "@/components/in-content-ad"
import Breadcrumbs from "@/components/breadcrumbs"
import RelatedGames from "@/components/related-games"
import SeoText from "@/components/seo-text"

export const metadata = {
  title: "About Our Retro Football Games Hub | Retro Football Hub",
  description:
    "Learn about RetroFootballHub, our mission to provide the best retro football gaming experience, and the team behind the site.",
}

export default function AboutPage() {
  const breadcrumbItems = [{ label: "About" }]

  return (
    <div className="container-custom py-6">
      <Breadcrumbs items={breadcrumbItems} />

      <h1 className="mb-4 text-center text-2xl font-bold md:text-3xl">About Our Retro Football Games Hub</h1>

      <div className="mx-auto max-w-3xl">
        <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
          <h2 className="mb-4 text-xl font-bold">Our Mission</h2>

          <SeoText>
            <p className="mb-4">
              Welcome to RetroFootballHub, the ultimate destination for fans of retro-styled football games! Our mission
              is simple: to provide a one-stop hub where players can enjoy the best retro football gaming experiences in
              one convenient location.
            </p>

            <p className="mb-4">
              We believe that great gameplay doesn't require cutting-edge graphics or complex controls. The charm of
              retro-styled games like Retro Bowl lies in their accessibility, depth, and that special nostalgic feeling
              they evoke. These games remind us of a simpler time in gaming while still delivering engaging, strategic
              gameplay that keeps you coming back for more.
            </p>

            <InContentAd />

            <p className="mb-4">
              Our site was created by a small team of passionate retro gaming enthusiasts who wanted to build a
              community around these beloved football games. We noticed that while these games have dedicated fan bases,
              there wasn't a central hub where players could access multiple games, share strategies, compare
              achievements, and connect with fellow fans.
            </p>

            <p className="mb-4">
              RetroFootballHub fills that gap by offering not just the games themselves, but comprehensive guides, tips,
              leaderboards, and community features that enhance your gaming experience. Whether you're a seasoned
              veteran with multiple championship wins or a newcomer just discovering the joy of retro football games,
              we've built this site with you in mind.
            </p>
          </SeoText>
        </div>

        <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
          <h2 className="mb-4 text-xl font-bold">Our Games</h2>

          <SeoText>
            <p className="mb-4">
              We feature a carefully curated selection of the best retro-styled football games available to play online:
            </p>

            <ul className="mb-4 list-disc space-y-3 pl-5">
              <li>
                <strong>Retro Bowl</strong> - The original phenomenon that captured the hearts of football gaming fans
                with its perfect blend of simple controls and deep management. Its pixelated graphics and accessible
                gameplay make it an instant classic.
              </li>
              <li>
                <strong>Retro Bowl 2</strong> - The sequel that builds on the original's success with enhanced graphics,
                expanded team options, and refined gameplay mechanics while maintaining the charm that made the original
                great.
              </li>
              <li>
                <strong>Retro Bowl 25</strong> - The latest edition featuring updated rosters, new stadiums, and
                improved game mechanics for the most comprehensive retro football experience yet.
              </li>
              <li>
                <strong>Retro Football</strong> - A different take on retro football gaming with more arcade-style
                gameplay, perfect for quick sessions and casual play.
              </li>
            </ul>

            <p className="mb-4">
              <strong>Important Disclaimer:</strong> RetroFootballHub is not affiliated with the official developers of
              Retro Bowl or any other games featured on this site. We are simply fans who want to share these games with
              a wider audience. All games are linked to their official sources, and we encourage supporting the original
              developers.
            </p>
          </SeoText>
        </div>

        <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
          <h2 className="mb-4 text-xl font-bold">Contact Us</h2>

          <div className="mb-6 text-sm">
            <p className="mb-4">
              Have questions, suggestions, or feedback? We'd love to hear from you! You can reach our team at{" "}
              <a href="mailto:support@retrofootballhub.com" className="text-primary hover:underline">
                support@retrofootballhub.com
              </a>{" "}
              or use the contact form below.
            </p>

            <p className="mb-4">
              We're always looking to improve RetroFootballHub and welcome your ideas on how we can make this the best
              possible community for retro football gaming fans.
            </p>
          </div>

          <form className="mx-auto max-w-md">
            <div className="grid grid-cols-1 gap-4">
              <div className="form-group">
                <label className="form-label">Your Name</label>
                <input type="text" className="form-input" placeholder="Enter your name" />
              </div>

              <div className="form-group">
                <label className="form-label">Email Address</label>
                <input type="email" className="form-input" placeholder="Enter your email" />
              </div>

              <div className="form-group">
                <label className="form-label">Subject</label>
                <input type="text" className="form-input" placeholder="Enter subject" />
              </div>

              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea className="form-textarea h-32" placeholder="Enter your message"></textarea>
              </div>

              <button type="submit" className="btn btn-primary">
                Send Message
              </button>
            </div>
          </form>
        </div>

        {/* Related Games */}
        <RelatedGames title="Our Featured Games" />
      </div>
    </div>
  )
}

