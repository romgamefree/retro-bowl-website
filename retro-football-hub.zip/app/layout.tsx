import type React from "react"
import type { Metadata } from "next/dist/lib/metadata/types/metadata-interface"
import { Inter, Oswald } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { cn } from "@/lib/utils"
import ScrollToTop from "@/components/scroll-to-top"
import FloatingGamesBubble from "@/components/floating-games-bubble"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const oswald = Oswald({
  subsets: ["latin"],
  variable: "--font-oswald",
})

export const metadata: Metadata = {
  title: "Play Retro Bowl Online | Free Retro Football Games Hub",
  description:
    "Enjoy Retro Bowl, Retro Bowl 2, Retro Bowl 25, and more retro football games online for free! No downloads needed - fun, fast, and unblocked.",
  keywords:
    "Retro Bowl, Retro Bowl 2, Retro Bowl 25, Retro Football, retro football games, play retro bowl online, retro football games unblocked",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-xxx"
          crossOrigin="anonymous"
        ></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body className={cn("min-h-screen bg-gray-50 font-sans antialiased", inter.variable, oswald.variable)}>
        <div className="flex min-h-screen flex-col">
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <ScrollToTop />
          <FloatingGamesBubble />
        </div>
      </body>
    </html>
  )
}



import './globals.css'