export const metadata = {
  title: "Terms of Use | Retro Football Hub",
  description:
    "Read our terms of use to understand the rules and guidelines for using RetroFootballHub and playing our retro football games.",
}

export default function TermsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-4xl font-pixel mb-6 text-center">Terms of Use</h1>

      <div className="max-w-3xl mx-auto bg-white p-6 pixel-border">
        <div className="prose max-w-none">
          <p className="mb-4">
            <strong>Last Updated:</strong> March 6, 2025
          </p>

          <p className="mb-4">
            Welcome to RetroFootballHub. These terms and conditions outline the rules and regulations for the use of our
            website.
          </p>

          <p className="mb-4">
            By accessing this website, we assume you accept these terms and conditions in full. Do not continue to use
            RetroFootballHub if you do not accept all of the terms and conditions stated on this page.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">1. License to Use</h2>

          <p className="mb-4">
            Unless otherwise stated, RetroFootballHub and/or its licensors own the intellectual property rights for all
            material on RetroFootballHub. All intellectual property rights are reserved.
          </p>

          <p className="mb-4">
            You may view and/or play games on this website for your own personal use subject to restrictions set in
            these terms and conditions.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">2. Restrictions</h2>

          <p className="mb-4">You are specifically restricted from all of the following:</p>

          <ul className="list-disc pl-5 space-y-2 mb-4">
            <li>Publishing any website material in any other media without proper attribution</li>
            <li>Selling, sublicensing and/or otherwise commercializing any website material</li>
            <li>Publicly performing and/or showing any website material without proper attribution</li>
            <li>Using this website in any way that is or may be damaging to this website</li>
            <li>Using this website in any way that impacts user access to this website</li>
            <li>
              Using this website contrary to applicable laws and regulations, or in any way may cause harm to the
              website, or to any person or business entity
            </li>
            <li>
              Engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to
              this website
            </li>
            <li>Using this website to engage in any advertising or marketing</li>
          </ul>

          <h2 className="text-xl font-pixel mt-6 mb-3">3. User Content</h2>

          <p className="mb-4">
            In these Terms and Conditions, "User Content" shall mean any text, images, videos, or other material which
            you submit to this website, including without limitation comments, forum posts, and profile information.
          </p>

          <p className="mb-4">
            By submitting User Content to this website, you grant RetroFootballHub a worldwide, irrevocable,
            non-exclusive, royalty-free license to use, reproduce, adapt, publish, translate and distribute your User
            Content in any existing or future media. You also grant RetroFootballHub the right to sub-license these
            rights, and the right to bring an action for infringement of these rights.
          </p>

          <p className="mb-4">
            Your User Content must not be illegal or unlawful, must not infringe any third party's legal rights, and
            must not be capable of giving rise to legal action whether against you or RetroFootballHub or a third party.
          </p>

          <p className="mb-4">
            RetroFootballHub reserves the right to edit or remove any material submitted to this website, or stored on
            our servers, or hosted or published upon this website.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">4. Games and External Links</h2>

          <p className="mb-4">
            RetroFootballHub provides access to various games and may link to other websites that are not under our
            control. We have no control over the nature, content, and availability of those games or sites. The
            inclusion of any links or games does not necessarily imply a recommendation or endorse the views expressed
            within them.
          </p>

          <p className="mb-4">
            We make every effort to keep the website up and running smoothly. However, RetroFootballHub takes no
            responsibility for, and will not be liable for, the website being temporarily unavailable due to technical
            issues beyond our control.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">5. Disclaimer</h2>

          <p className="mb-4">
            To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions
            relating to our website and the use of this website. Nothing in this disclaimer will:
          </p>

          <ul className="list-disc pl-5 space-y-2 mb-4">
            <li>Limit or exclude our or your liability for death or personal injury</li>
            <li>Limit or exclude our or your liability for fraud or fraudulent misrepresentation</li>
            <li>Limit any of our or your liabilities in any way that is not permitted under applicable law</li>
            <li>Exclude any of our or your liabilities that may not be excluded under applicable law</li>
          </ul>

          <p className="mb-4">
            The limitations and prohibitions of liability set in this Section and elsewhere in this disclaimer: (a) are
            subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer, including
            liabilities arising in contract, in tort and for breach of statutory duty.
          </p>

          <p className="mb-4">
            As long as the website and the information and services on the website are provided free of charge, we will
            not be liable for any loss or damage of any nature.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">6. Changes to Terms</h2>

          <p className="mb-4">
            RetroFootballHub reserves the right to revise these terms of use at any time as it sees fit, and by using
            this website you are expected to review these terms regularly to ensure you understand all terms and
            conditions governing use of this website.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">7. Governing Law</h2>

          <p className="mb-4">
            These terms and conditions are governed by and construed in accordance with the laws of the United States,
            and you irrevocably submit to the exclusive jurisdiction of the courts in that location.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">8. Contact Us</h2>

          <p className="mb-4">
            If you have any questions about these Terms of Use, please contact us at support@retrofootballhub.com.
          </p>
        </div>
      </div>
    </div>
  )
}

