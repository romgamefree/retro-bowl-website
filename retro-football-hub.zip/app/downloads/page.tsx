import Link from "next/link"
import InContentAd from "@/components/in-content-ad"

export const metadata = {
  title: "Download Retro Football Games Offline | Retro Football Hub",
  description:
    "Download Retro Bowl, Retro Bowl 2, Retro Bowl 25, and Retro Football games for offline play on mobile devices and computers.",
}

export default function DownloadsPage() {
  const downloadOptions = [
    {
      title: "Retro Bowl",
      platforms: [
        { name: "iOS", url: "https://apps.apple.com/us/app/retro-bowl/id1478902583", icon: "apple" },
        {
          name: "Android",
          url: "https://play.google.com/store/apps/details?id=com.newstargames.retrobowl",
          icon: "android",
        },
        { name: "Steam", url: "https://store.steampowered.com/app/1620560/Retro_Bowl/", icon: "steam" },
      ],
      description: "The original retro-styled American football game that combines management and gameplay.",
    },
    {
      title: "Retro Bowl 2",
      platforms: [
        { name: "iOS", url: "#", icon: "apple" },
        { name: "Android", url: "#", icon: "android" },
      ],
      description: "The sequel with enhanced graphics, more teams, and expanded gameplay options.",
    },
    {
      title: "Retro Bowl 25",
      platforms: [
        { name: "iOS", url: "#", icon: "apple" },
        { name: "Android", url: "#", icon: "android" },
        { name: "Steam", url: "#", icon: "steam" },
      ],
      description: "The latest edition with updated rosters, new stadiums, and improved game mechanics.",
    },
    {
      title: "Retro Football",
      platforms: [
        { name: "iOS", url: "#", icon: "apple" },
        { name: "Android", url: "#", icon: "android" },
      ],
      description: "A pixel-perfect football experience with arcade-style gameplay and retro aesthetics.",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-4xl font-pixel mb-6 text-center">Download Retro Football Games Offline</h1>

      <div className="max-w-3xl mx-auto">
        <div className="bg-white p-6 pixel-border mb-8">
          <h2 className="text-2xl font-pixel mb-4">Official Downloads</h2>

          <div className="prose max-w-none">
            <p className="mb-6">
              While you can play all our featured games directly in your browser, you might want to download them for
              offline play. Below are links to the official app stores and platforms where you can download these games.
            </p>

            <InContentAd />

            <div className="space-y-8 mt-8">
              {downloadOptions.map((game) => (
                <div key={game.title} className="border-2 border-black p-4">
                  <h3 className="font-pixel text-xl mb-2">{game.title}</h3>
                  <p className="text-sm mb-4">{game.description}</p>

                  <div className="flex flex-wrap gap-3">
                    {game.platforms.map((platform) => (
                      <Link
                        key={platform.name}
                        href={platform.url}
                        className="flex items-center gap-2 bg-retro-blue text-white px-4 py-2 rounded-sm hover:bg-retro-light-blue transition-colors"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <span>{platform.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white p-6 pixel-border mb-8">
          <h2 className="text-2xl font-pixel mb-4">System Requirements</h2>

          <div className="prose max-w-none">
            <p className="mb-4">
              One of the great things about retro-styled games is that they typically have very modest system
              requirements. Here's what you'll need to run these games smoothly:
            </p>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-pixel mb-2">Mobile Devices (iOS/Android)</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>iOS 10.0 or later / Android 5.0 or later</li>
                  <li>At least 100MB of free storage space</li>
                  <li>1GB RAM or more recommended</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-pixel mb-2">PC/Mac (Steam)</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Windows 7 or later / macOS 10.12 or later</li>
                  <li>Intel Core i3 or equivalent</li>
                  <li>2GB RAM</li>
                  <li>200MB available space</li>
                  <li>Any dedicated graphics card (integrated graphics will work fine too)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 pixel-border">
          <h2 className="text-2xl font-pixel mb-4">Offline vs. Online Play</h2>

          <div className="prose max-w-none">
            <p className="mb-4">
              While downloading these games for offline play has its advantages, playing online on RetroFootballHub
              offers some unique benefits:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="border-2 border-black p-4">
                <h3 className="font-pixel text-lg mb-2">Offline Advantages</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Play anywhere without internet connection</li>
                  <li>No ads (for paid versions)</li>
                  <li>One-time download</li>
                  <li>Potentially smoother performance</li>
                </ul>
              </div>

              <div className="border-2 border-black p-4">
                <h3 className="font-pixel text-lg mb-2">Online Advantages</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>No downloads required</li>
                  <li>Access to community features</li>
                  <li>Leaderboard participation</li>
                  <li>Always have the latest version</li>
                  <li>Play across multiple devices without syncing</li>
                </ul>
              </div>
            </div>

            <p>
              Whether you choose to play online or download for offline play, we're happy to have you as part of our
              retro football gaming community!
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

