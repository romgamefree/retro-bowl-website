import AdSidebar from "@/components/ad-sidebar"
import Breadcrumbs from "@/components/breadcrumbs"
import RelatedGames from "@/components/related-games"

export const metadata = {
  title: "Retro Football Leaderboards - Top Players Across Games | Retro Football Hub",
  description:
    "Check out the top players and highest scores for Retro Bowl, Retro Bowl 2, Retro Bowl 25, and Retro Football games. Can you make it to the top?",
}

export default function LeaderboardsPage() {
  // Mock leaderboard data
  const retroBowlLeaders = [
    { rank: 1, player: "RetroChamp88", score: "15 Championships", team: "New York" },
    { rank: 2, player: "QBLegend", score: "14 Championships", team: "Dallas" },
    { rank: 3, player: "FootballWizard", score: "13 Championships", team: "San Francisco" },
    { rank: 4, player: "GridironKing", score: "12 Championships", team: "Kansas City" },
    { rank: 5, player: "PixelPasser", score: "11 Championships", team: "Green Bay" },
    { rank: 6, player: "TouchdownTitan", score: "10 Championships", team: "Pittsburgh" },
    { rank: 7, player: "EndZoneElite", score: "9 Championships", team: "Baltimore" },
    { rank: 8, player: "VintageVictor", score: "8 Championships", team: "New England" },
    { rank: 9, player: "RetroRunner", score: "7 Championships", team: "Seattle" },
    { rank: 10, player: "PixelPunter", score: "6 Championships", team: "Los Angeles" },
  ]

  const retroBowl2Leaders = [
    { rank: 1, player: "PixelPro", score: "2,450 Points", team: "Miami" },
    { rank: 2, player: "RetroRookie", score: "2,380 Points", team: "Buffalo" },
    { rank: 3, player: "GridironGuru", score: "2,310 Points", team: "Cincinnati" },
    { rank: 4, player: "PixelatedPasser", score: "2,290 Points", team: "Tennessee" },
    { rank: 5, player: "VintageVictory", score: "2,240 Points", team: "Indianapolis" },
    { rank: 6, player: "BitBaller", score: "2,190 Points", team: "Jacksonville" },
    { rank: 7, player: "DigitalDefender", score: "2,150 Points", team: "Houston" },
    { rank: 8, player: "ClassicCoach", score: "2,120 Points", team: "Las Vegas" },
    { rank: 9, player: "RetroReceiver", score: "2,080 Points", team: "Los Angeles" },
    { rank: 10, player: "PixelPunt", score: "2,050 Points", team: "Denver" },
  ]

  const breadcrumbItems = [{ label: "Leaderboards" }]

  return (
    <div className="container-custom py-6">
      <Breadcrumbs items={breadcrumbItems} />

      <h1 className="mb-4 text-center text-2xl font-bold md:text-3xl">
        Retro Football Leaderboards - Top Players Across Games
      </h1>

      <div className="flex flex-col gap-6 lg:flex-row lg:gap-8">
        <div className="lg:w-3/4">
          <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
            <h2 className="mb-4 text-xl font-bold">Retro Bowl Champions</h2>

            <div className="table-container">
              <table className="table" itemScope itemType="https://schema.org/Table">
                <thead className="table-header">
                  <tr>
                    <th className="table-header-cell">Rank</th>
                    <th className="table-header-cell">Player</th>
                    <th className="table-header-cell">Achievement</th>
                    <th className="table-header-cell">Team</th>
                  </tr>
                </thead>
                <tbody className="table-body">
                  {retroBowlLeaders.map((leader) => (
                    <tr key={leader.rank} className="table-row">
                      <td className="table-cell font-medium">{leader.rank}</td>
                      <td className="table-cell">{leader.player}</td>
                      <td className="table-cell">{leader.score}</td>
                      <td className="table-cell">{leader.team}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
            <h2 className="mb-4 text-xl font-bold">Retro Bowl 2 High Scores</h2>

            <div className="table-container">
              <table className="table" itemScope itemType="https://schema.org/Table">
                <thead className="table-header">
                  <tr>
                    <th className="table-header-cell">Rank</th>
                    <th className="table-header-cell">Player</th>
                    <th className="table-header-cell">Score</th>
                    <th className="table-header-cell">Team</th>
                  </tr>
                </thead>
                <tbody className="table-body">
                  {retroBowl2Leaders.map((leader) => (
                    <tr key={leader.rank} className="table-row">
                      <td className="table-cell font-medium">{leader.rank}</td>
                      <td className="table-cell">{leader.player}</td>
                      <td className="table-cell">{leader.score}</td>
                      <td className="table-cell">{leader.team}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
            <h2 className="mb-4 text-xl font-bold">Submit Your Score</h2>
            <p className="mb-4 text-center text-sm">
              Think you have what it takes to make it onto our leaderboards? Submit your best achievements below!
            </p>

            <form className="mx-auto max-w-md">
              <div className="grid grid-cols-1 gap-4">
                <div className="form-group">
                  <label className="form-label">Your Username</label>
                  <input type="text" className="form-input" placeholder="Enter your username" />
                </div>

                <div className="form-group">
                  <label className="form-label">Game</label>
                  <select className="form-select">
                    <option>Retro Bowl</option>
                    <option>Retro Bowl 2</option>
                    <option>Retro Bowl 25</option>
                    <option>Retro Football</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Achievement/Score</label>
                  <input type="text" className="form-input" placeholder="Enter your score or achievement" />
                </div>

                <div className="form-group">
                  <label className="form-label">Team</label>
                  <input type="text" className="form-input" placeholder="Enter your team name" />
                </div>

                <div className="form-group">
                  <label className="form-label">Screenshot (Optional)</label>
                  <input type="file" className="form-input" />
                </div>

                <button type="submit" className="btn btn-primary">
                  Submit Score
                </button>
              </div>
            </form>
          </div>

          {/* Related Games */}
          <RelatedGames title="Compete in These Games" />
        </div>

        <AdSidebar />
      </div>
    </div>
  )
}

