"use client"

import Link from "next/link"
import { notFound } from "next/navigation"
import InContentAd from "@/components/in-content-ad"
import Breadcrumbs from "@/components/breadcrumbs"
import RelatedGames from "@/components/related-games"
import SeoText from "@/components/seo-text"
import { useEffect } from "react"

interface GamePageProps {
  params: {
    game: string
  }
}

export function generateMetadata({ params }: GamePageProps) {
  const gameSlug = params.game

  const games = {
    "retro-bowl": {
      title: "Play Retro Bowl Online Free | Retro Football Hub",
      description:
        "Play Retro Bowl online for free - no downloads needed. Experience the classic retro-styled American football game with simple controls and deep gameplay.",
    },
    "retro-bowl-2": {
      title: "Play Retro Bowl 2 Online Free | Retro Football Hub",
      description:
        "Play Retro Bowl 2 online for free with enhanced graphics and expanded gameplay. The sequel to the hit retro football game is here!",
    },
    "retro-bowl-25": {
      title: "Play Retro Bowl 25 Online Free | Retro Football Hub",
      description:
        "Play Retro Bowl 25 online for free with updated rosters and improved game mechanics. The latest edition of the popular retro football series.",
    },
    "retro-football": {
      title: "Play Retro Football Online Free | Retro Football Hub",
      description:
        "Play Retro Football online for free - an arcade-style pixel-perfect football experience with retro aesthetics and fun gameplay.",
    },
  }

  const game = games[gameSlug as keyof typeof games]

  if (!game) {
    return {
      title: "Game Not Found | Retro Football Hub",
      description: "The requested game could not be found on Retro Football Hub.",
    }
  }

  return {
    title: game.title,
    description: game.description,
  }
}

export default function GamePage({ params }: GamePageProps) {
  const gameSlug = params.game

  const games = {
    "retro-bowl": {
      title: "Retro Bowl",
      description: "The classic retro-styled American football game that combines simple gameplay with deep strategy.",
      instructions:
        "Use arrow keys to move, Z to pass/select, X to rush/dive. Manage your team between games to build a dynasty.",
      iframeUrl: "https://retrobowl.click/game/retro-bowl",
      seoText:
        "Retro Bowl is a popular American football game that combines retro-styled graphics with engaging gameplay. Developed with a focus on simplicity and fun, this game allows players to manage their team, draft players, and compete in championships. The pixel art graphics give it a nostalgic feel while the strategic depth keeps players coming back for more. Perfect for football fans who appreciate classic gaming aesthetics.",
    },
    "retro-bowl-2": {
      title: "Retro Bowl 2",
      description: "The sequel to the hit game with enhanced graphics, more teams, and expanded gameplay options.",
      instructions:
        "Controls are similar to the original. New features include weather effects and an expanded playbook.",
      iframeUrl: "https://retrobowl.click/game/retro-bowl",
      seoText:
        "Retro Bowl 2 builds upon the success of its predecessor with enhanced graphics, more teams, and expanded gameplay options. This sequel maintains the beloved pixel art style while adding more detail and depth to the football simulation. New features include weather effects that impact gameplay, an expanded playbook for more strategic options, and improved team management systems. Fans of the original will appreciate the familiar controls while enjoying the new content.",
    },
    "retro-bowl-25": {
      title: "Retro Bowl 25",
      description: "The latest edition with updated rosters, new stadiums, and improved game mechanics.",
      instructions:
        "Use arrow keys or WASD to move, Z/J to pass/select, X/K to rush/dive. New features include franchise mode and player progression.",
      iframeUrl: "https://retrobowl.click/game/retro-bowl",
      seoText:
        "Retro Bowl 25 represents the latest evolution in the popular retro football gaming series. This edition features updated rosters reflecting current football talent, new stadiums to play in, and significantly improved game mechanics. The franchise mode allows for deeper team building over multiple seasons, while the enhanced player progression system gives each athlete a more unique development path. Despite these modern features, Retro Bowl 25 stays true to its retro roots with charming pixel graphics and accessible controls.",
    },
    "retro-football": {
      title: "Retro Football",
      description: "A pixel-perfect football experience with arcade-style gameplay and retro aesthetics.",
      instructions:
        "Use arrow keys to move, Z for action, X for special moves. Collect power-ups to gain advantages during gameplay.",
      iframeUrl: "https://retrobowl.click/game/retro-bowl",
      seoText:
        "Retro Football offers a different take on the digital gridiron experience with its arcade-style gameplay and authentic retro aesthetics. Unlike simulation-focused games, Retro Football emphasizes quick, fun gameplay sessions with power-ups, special moves, and fast-paced action. The pixel-perfect visuals capture the essence of classic sports games from the 8-bit and 16-bit eras, making it a nostalgic treat for gamers who grew up in that golden age of arcade sports titles.",
    },
  }

  const game = games[gameSlug as keyof typeof games]

  if (!game) {
    notFound()
  }

  const breadcrumbItems = [{ label: "Play", href: "/play" }, { label: game.title }]

  // Open other game links in new tabs
  useEffect(() => {
    const gameLinks = document.querySelectorAll(".related-game-item")
    gameLinks.forEach((link) => {
      if (link instanceof HTMLAnchorElement) {
        link.setAttribute("target", "_blank")
      }
    })
  }, [])

  return (
    <div className="container-custom py-6">
      <Breadcrumbs items={breadcrumbItems} />

      <h1 className="mb-4 text-center text-2xl font-bold md:text-3xl">Play {game.title} Online Free</h1>

      <div className="mx-auto max-w-4xl">
        <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
          <div className="game-iframe-container mb-4">
            <iframe
              src={game.iframeUrl}
              className="game-iframe"
              title={`Play ${game.title} Online`}
              allow="fullscreen"
              loading="lazy"
            ></iframe>
          </div>

          <div className="mb-4 flex flex-wrap justify-center gap-3">
            <button
              className="btn btn-primary btn-sm"
              onClick={() => {
                const iframe = document.querySelector(".game-iframe") as HTMLIFrameElement
                if (iframe) {
                  iframe.requestFullscreen().catch((err) => {
                    console.log("Error attempting to enable fullscreen:", err)
                  })
                }
              }}
            >
              Fullscreen
            </button>
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => {
                const iframe = document.querySelector(".game-iframe") as HTMLIFrameElement
                if (iframe) {
                  iframe.src = iframe.src
                }
              }}
            >
              Restart
            </button>
            <Link href="/" className="btn btn-secondary btn-sm">
              More Games
            </Link>
          </div>

          <InContentAd />

          <div className="mt-6">
            <h2 className="mb-3 text-xl font-bold">How to Play {game.title}</h2>

            <SeoText>
              <p className="mb-4">{game.description}</p>

              <h3 className="mb-2 mt-4 text-lg font-bold">Controls & Instructions</h3>

              <p className="mb-4">{game.instructions}</p>

              <h3 className="mb-2 mt-4 text-lg font-bold">Tips for Success</h3>

              <ul className="mb-4 list-disc space-y-1 pl-5">
                <li>Take your time to learn the controls before diving into a full season</li>
                <li>Focus on upgrading key positions first (QB, WR, DB)</li>
                <li>Manage your team's morale to keep performance high</li>
                <li>Use the dive button near the sideline to avoid going out of bounds</li>
                <li>Practice makes perfect - don't get discouraged if you lose early games</li>
              </ul>

              <p className="mb-4">{game.seoText}</p>

              <Link href="/tips" className="text-primary hover:underline">
                View our complete strategy guide for more tips →
              </Link>
            </SeoText>
          </div>
        </div>

        {/* Related Games */}
        <RelatedGames currentGame={gameSlug} title="More Football Games You Might Enjoy" />

        <div className="mt-6 rounded-lg bg-white p-4 shadow-md md:p-6">
          <h2 className="mb-4 text-xl font-bold">Comments</h2>

          <div className="mb-6 space-y-4">
            <div className="rounded border border-gray-200 p-3">
              <div className="mb-2 flex justify-between items-start">
                <p className="font-medium">RetroChamp88</p>
                <span className="text-xs text-gray-500">2 days ago</span>
              </div>
              <p className="text-sm">
                This game is amazing! I've been playing for hours and can't put it down. Already won 3 championships!
              </p>
            </div>

            <div className="rounded border border-gray-200 p-3">
              <div className="mb-2 flex justify-between items-start">
                <p className="font-medium">PixelPasser</p>
                <span className="text-xs text-gray-500">5 days ago</span>
              </div>
              <p className="text-sm">
                The controls take some getting used to, but once you master them it's super fun. Love the retro
                graphics!
              </p>
            </div>

            <div className="rounded border border-gray-200 p-3">
              <div className="mb-2 flex justify-between items-start">
                <p className="font-medium">GridironGuru</p>
                <span className="text-xs text-gray-500">1 week ago</span>
              </div>
              <p className="text-sm">
                Pro tip: Focus on your offensive line early. It makes a huge difference in giving your QB time to throw.
              </p>
            </div>
          </div>

          <form>
            <div className="form-group">
              <label className="form-label">Your Name</label>
              <input type="text" className="form-input" placeholder="Enter your name" />
            </div>

            <div className="form-group">
              <label className="form-label">Your Comment</label>
              <textarea className="form-textarea h-24" placeholder="Share your thoughts about the game..."></textarea>
            </div>

            <button type="submit" className="btn btn-primary">
              Post Comment
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

