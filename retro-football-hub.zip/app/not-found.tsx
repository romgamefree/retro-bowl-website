import Link from "next/link"

export default function NotFound() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-md mx-auto text-center">
        <h1 className="text-4xl font-pixel mb-6">404</h1>
        <h2 className="text-2xl font-pixel mb-4">Game Not Found</h2>
        <p className="mb-8">
          Sorry, the game you're looking for doesn't exist or has been moved to a different location.
        </p>
        <Link href="/" className="pixel-button">
          Return to Homepage
        </Link>
      </div>
    </div>
  )
}

