import AdSidebar from "@/components/ad-sidebar"
import InContentAd from "@/components/in-content-ad"
import Breadcrumbs from "@/components/breadcrumbs"
import RelatedGames from "@/components/related-games"

export const metadata = {
  title: "Retro Football Community - Connect & Share | Retro Football Hub",
  description:
    "Join the Retro Football community to discuss strategies, share achievements, and connect with other fans of Retro Bowl and retro football games.",
}

export default function CommunityPage() {
  // Mock community posts
  const communityPosts = [
    {
      id: 1,
      author: "RetroChamp88",
      title: "My 15-Season Championship Strategy",
      content:
        "After winning 15 consecutive championships in Retro Bowl, I wanted to share my strategy. The key is to focus on QB and WR development first, then gradually build your defense starting with DBs...",
      date: "2 days ago",
      likes: 42,
      comments: 18,
    },
    {
      id: 2,
      author: "PixelPasser",
      title: "Retro Bowl 2 Weather Tips",
      content:
        "I've been experimenting with different strategies for the new weather system in Retro Bowl 2. Here's what works best for each condition: In rain, focus on running plays and short passes...",
      date: "4 days ago",
      likes: 36,
      comments: 15,
    },
    {
      id: 3,
      author: "GridironGuru",
      title: "Retro Bowl 25 Draft Guide",
      content:
        "The expanded draft in Retro Bowl 25 offers more opportunities but also more complexity. Here's my comprehensive guide to making the most of each round and finding those hidden gems...",
      date: "1 week ago",
      likes: 29,
      comments: 12,
    },
    {
      id: 4,
      author: "VintageVictor",
      title: "Retro Football Power-Up Combinations",
      content:
        "I've discovered some amazing power-up combinations in Retro Football that can help you dominate the arcade mode. The Speed Boost + Accuracy Enhancement is particularly effective when...",
      date: "1 week ago",
      likes: 24,
      comments: 9,
    },
    {
      id: 5,
      author: "PixelPunter",
      title: "Best Defensive Formations",
      content:
        "After extensive testing, I've ranked all the defensive formations in Retro Bowl 2. The 4-3 seems most effective against run-heavy teams, while the Nickel package shuts down passing attacks...",
      date: "2 weeks ago",
      likes: 31,
      comments: 14,
    },
  ]

  const breadcrumbItems = [{ label: "Community" }]

  return (
    <div className="container-custom py-6">
      <Breadcrumbs items={breadcrumbItems} />

      <h1 className="mb-4 text-center text-2xl font-bold md:text-3xl">Retro Football Community - Connect & Share</h1>

      <div className="flex flex-col gap-6 lg:flex-row lg:gap-8">
        <div className="lg:w-3/4">
          <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
            <h2 className="mb-4 text-xl font-bold">Community Discussion</h2>

            <div className="mb-6">
              <p className="mb-4 text-sm">
                Welcome to our community section! This is where retro football gamers come together to share strategies,
                celebrate achievements, and help each other improve. Join the conversation by commenting on existing
                posts or creating your own.
              </p>

              <div className="flex justify-center">
                <button className="btn btn-primary">Create New Post</button>
              </div>
            </div>

            <InContentAd />

            <div className="mt-6 space-y-4">
              {communityPosts.map((post) => (
                <div
                  key={post.id}
                  className="rounded-lg border border-gray-200 p-4 transition-all hover:border-primary/30 hover:shadow-sm"
                >
                  <div className="mb-2 flex justify-between items-start">
                    <h3 className="font-bold">{post.title}</h3>
                    <span className="text-xs text-gray-500">{post.date}</span>
                  </div>

                  <p className="mb-2 text-xs text-gray-600">
                    Posted by: <span className="font-medium">{post.author}</span>
                  </p>

                  <p className="mb-3 text-sm">{post.content}</p>

                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-4">
                      <button className="flex items-center gap-1 text-gray-600 hover:text-primary">
                        <span>👍</span> {post.likes}
                      </button>
                      <span className="text-gray-600">{post.comments} comments</span>
                    </div>

                    <button className="text-primary hover:underline">Read More</button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 text-center">
              <button className="btn btn-secondary">Load More Posts</button>
            </div>
          </div>

          <div className="mb-6 rounded-lg bg-white p-4 shadow-md md:p-6">
            <h2 className="mb-4 text-xl font-bold">Weekly Challenge</h2>

            <div className="mb-6 rounded-lg border border-gray-200 bg-gray-50 p-4">
              <h3 className="mb-2 text-lg font-bold">Retro Bowl Challenge: The Comeback King</h3>

              <p className="mb-3 text-sm">
                <strong>Challenge:</strong> Win a game after being down by at least 14 points in the 4th quarter.
              </p>

              <p className="mb-2 text-sm">
                <strong>Rules:</strong>
              </p>

              <ul className="mb-4 list-disc space-y-1 pl-5 text-sm">
                <li>Must be played on Dynamic difficulty or higher</li>
                <li>Must be a regular season or playoff game</li>
                <li>Submit a screenshot of the final score and quarter-by-quarter breakdown</li>
              </ul>

              <p className="mb-4 text-sm">
                <strong>Prize:</strong> Featured spot on next week's community highlights and special forum badge
              </p>

              <div className="text-center">
                <button className="btn btn-primary btn-sm">Submit Your Entry</button>
              </div>
            </div>

            <h3 className="mb-3 text-lg font-bold">Last Week's Winners</h3>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded border border-gray-200 p-3 text-center">
                <p className="mb-1 font-bold text-sm">🥇 First Place</p>
                <p className="text-sm font-medium">TouchdownTitan</p>
                <p className="text-xs text-gray-600">Score: 56-0</p>
              </div>

              <div className="rounded border border-gray-200 p-3 text-center">
                <p className="mb-1 font-bold text-sm">🥈 Second Place</p>
                <p className="text-sm font-medium">PixelPasser</p>
                <p className="text-xs text-gray-600">Score: 49-3</p>
              </div>

              <div className="rounded border border-gray-200 p-3 text-center">
                <p className="mb-1 font-bold text-sm">🥉 Third Place</p>
                <p className="text-sm font-medium">RetroRookie</p>
                <p className="text-xs text-gray-600">Score: 42-7</p>
              </div>
            </div>
          </div>

          {/* Related Games */}
          <RelatedGames title="Join These Game Communities" />
        </div>

        <AdSidebar />
      </div>
    </div>
  )
}

