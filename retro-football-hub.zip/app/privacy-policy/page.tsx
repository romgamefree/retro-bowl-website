export const metadata = {
  title: "Privacy Policy | Retro Football Hub",
  description:
    "Read our privacy policy to understand how we collect, use, and protect your data when you use RetroFootballHub.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-4xl font-pixel mb-6 text-center">Privacy Policy</h1>

      <div className="max-w-3xl mx-auto bg-white p-6 pixel-border">
        <div className="prose max-w-none">
          <p className="mb-4">
            <strong>Last Updated:</strong> March 6, 2025
          </p>

          <p className="mb-4">
            Welcome to RetroFootballHub. We respect your privacy and are committed to protecting your personal data.
            This privacy policy will inform you about how we look after your personal data when you visit our website
            and tell you about your privacy rights and how the law protects you.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">1. Important Information and Who We Are</h2>

          <p className="mb-4">
            RetroFootballHub is operated by Retro Gaming Enthusiasts LLC. We are the controller and responsible for your
            personal data (collectively referred to as "we", "us" or "our" in this privacy policy).
          </p>

          <p className="mb-4">
            If you have any questions about this privacy policy or our privacy practices, please contact us at
            support@retrofootballhub.com.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">2. The Data We Collect About You</h2>

          <p className="mb-4">
            We may collect, use, store and transfer different kinds of personal data about you which we have grouped
            together as follows:
          </p>

          <ul className="list-disc pl-5 space-y-2 mb-4">
            <li>
              <strong>Identity Data</strong> includes username or similar identifier.
            </li>
            <li>
              <strong>Contact Data</strong> includes email address.
            </li>
            <li>
              <strong>Technical Data</strong> includes internet protocol (IP) address, browser type and version, time
              zone setting and location, browser plug-in types and versions, operating system and platform, and other
              technology on the devices you use to access this website.
            </li>
            <li>
              <strong>Usage Data</strong> includes information about how you use our website and services.
            </li>
            <li>
              <strong>Game Data</strong> includes your scores, achievements, and other game-related information you
              choose to share.
            </li>
          </ul>

          <h2 className="text-xl font-pixel mt-6 mb-3">3. How We Use Your Personal Data</h2>

          <p className="mb-4">
            We will only use your personal data when the law allows us to. Most commonly, we will use your personal data
            in the following circumstances:
          </p>

          <ul className="list-disc pl-5 space-y-2 mb-4">
            <li>To register you as a new user.</li>
            <li>To manage our relationship with you.</li>
            <li>To enable you to participate in community features.</li>
            <li>To administer and protect our business and this website.</li>
            <li>
              To deliver relevant website content and advertisements to you and measure or understand the effectiveness
              of the advertising we serve to you.
            </li>
            <li>
              To use data analytics to improve our website, products/services, marketing, customer relationships and
              experiences.
            </li>
          </ul>

          <h2 className="text-xl font-pixel mt-6 mb-3">4. Cookies</h2>

          <p className="mb-4">
            We use cookies and similar tracking technologies to track the activity on our website and hold certain
            information. Cookies are files with small amount of data which may include an anonymous unique identifier.
          </p>

          <p className="mb-4">
            You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if
            you do not accept cookies, you may not be able to use some portions of our website.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">5. Advertising</h2>

          <p className="mb-4">
            We use Google AdSense to serve advertisements on our website. Google AdSense may use cookies and web beacons
            to collect data about your visits to this and other websites in order to provide relevant advertisements
            about goods and services that may interest you.
          </p>

          <p className="mb-4">
            If you would like more information about this practice and to know your choices about not having this
            information used by Google AdSense, please visit Google's privacy policy:
            https://policies.google.com/privacy.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">6. Data Security</h2>

          <p className="mb-4">
            We have put in place appropriate security measures to prevent your personal data from being accidentally
            lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your
            personal data to those employees, agents, contractors and other third parties who have a business need to
            know.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">7. Data Retention</h2>

          <p className="mb-4">
            We will only retain your personal data for as long as necessary to fulfill the purposes we collected it for,
            including for the purposes of satisfying any legal, accounting, or reporting requirements.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">8. Your Legal Rights</h2>

          <p className="mb-4">
            Under certain circumstances, you have rights under data protection laws in relation to your personal data,
            including the right to:
          </p>

          <ul className="list-disc pl-5 space-y-2 mb-4">
            <li>Request access to your personal data.</li>
            <li>Request correction of your personal data.</li>
            <li>Request erasure of your personal data.</li>
            <li>Object to processing of your personal data.</li>
            <li>Request restriction of processing your personal data.</li>
            <li>Request transfer of your personal data.</li>
            <li>Right to withdraw consent.</li>
          </ul>

          <p className="mb-4">
            If you wish to exercise any of these rights, please contact us at support@retrofootballhub.com.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">9. Changes to This Privacy Policy</h2>

          <p className="mb-4">
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
            Privacy Policy on this page and updating the "Last Updated" date at the top of this Privacy Policy.
          </p>

          <p className="mb-4">
            You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy
            are effective when they are posted on this page.
          </p>

          <h2 className="text-xl font-pixel mt-6 mb-3">10. Contact Us</h2>

          <p className="mb-4">
            If you have any questions about this Privacy Policy, please contact us at support@retrofootballhub.com.
          </p>
        </div>
      </div>
    </div>
  )
}

