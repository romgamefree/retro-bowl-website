"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Gamepad2, X } from "lucide-react"

interface Game {
  title: string
  slug: string
  imageUrl: string
}

export default function FloatingGamesBubble() {
  const [isOpen, setIsOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  // Show the bubble after 3 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 3000)

    return () => clearTimeout(timer)
  }, [])

  const games: Game[] = [
    {
      title: "Retro Bowl",
      slug: "retro-bowl",
      imageUrl: "/game-retro-bowl.jpg",
    },
    {
      title: "Retro Bowl 2",
      slug: "retro-bowl-2",
      imageUrl: "/game-retro-bowl-2.jpg",
    },
    {
      title: "Retro Bowl 25",
      slug: "retro-bowl-25",
      imageUrl: "/game-retro-bowl-25.jpg",
    },
    {
      title: "Retro Football",
      slug: "retro-football",
      imageUrl: "/game-retro-football.jpg",
    },
    {
      title: "Football Stars",
      slug: "football-stars",
      imageUrl: "/game-football-stars.jpg",
    },
    {
      title: "Touchdown Pro",
      slug: "touchdown-pro",
      imageUrl: "/game-touchdown-pro.jpg",
    },
  ]

  if (!isVisible) return null

  return (
    <>
      {/* Floating Bubble */}
      <button
        className={`fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-white shadow-lg transition-all hover:bg-primary/90 ${isOpen ? "scale-0" : "scale-100"}`}
        onClick={() => setIsOpen(true)}
        aria-label="Show more games"
      >
        <Gamepad2 className="h-6 w-6" />
        <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold">
          {games.length}
        </span>
      </button>

      {/* Popup */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 z-50 m-4 max-w-sm overflow-hidden rounded-lg bg-white shadow-xl md:bottom-6 md:right-6">
          <div className="flex items-center justify-between border-b p-4">
            <h3 className="font-heading text-lg font-bold">More Games to Play</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="rounded-full p-1 text-gray-500 hover:bg-gray-100"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto p-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {games.map((game) => (
                <a
                  key={game.slug}
                  href={`/play/${game.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex flex-col items-center rounded-md border border-gray-100 p-2 text-center transition-all hover:border-primary/20 hover:bg-gray-50"
                >
                  <div className="relative mb-2 h-16 w-16 overflow-hidden rounded-md">
                    <Image
                      src={game.imageUrl || "/placeholder.svg"}
                      alt={game.title}
                      fill
                      className="object-cover transition-transform group-hover:scale-110"
                    />
                  </div>
                  <span className="text-xs font-medium group-hover:text-primary">{game.title}</span>
                </a>
              ))}
            </div>
          </div>

          <div className="border-t bg-gray-50 p-3 text-center">
            <p className="text-xs text-gray-500">Click any game to open in a new tab</p>
          </div>
        </div>
      )}
    </>
  )
}

