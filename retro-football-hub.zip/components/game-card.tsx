import Image from "next/image"
import Link from "next/link"

interface GameCardProps {
  title: string
  slug: string
  description: string
  imageUrl: string
  altText: string
}

export default function GameCard({ title, slug, description, imageUrl, altText }: GameCardProps) {
  return (
    <div className="card overflow-hidden">
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={imageUrl || "/placeholder.svg"}
          alt={altText}
          fill
          className="object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <div className="p-4">
        <h3 className="mb-2 text-lg font-bold">{title}</h3>
        <p className="mb-4 text-sm text-gray-600">{description}</p>
        <Link href={`/play/${slug}`} className="btn btn-primary btn-sm">
          Play Now
        </Link>
      </div>
    </div>
  )
}

