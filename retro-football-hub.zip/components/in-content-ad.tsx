export default function InContentAd() {
  return (
    <div className="adsense-container my-8">
      <ins
        className="adsbygoogle"
        style={{ display: "inline-block", width: "336px", height: "280px" }}
        data-ad-client="ca-pub-xxx"
        data-ad-slot="xxx"
      ></ins>
      <script
        dangerouslySetInnerHTML={{
          __html: `
        (adsbygoogle = window.adsbygoogle || []).push({});
      `,
        }}
      />
    </div>
  )
}

