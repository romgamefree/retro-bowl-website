import type React from "react"
interface SeoTextProps {
  children: React.ReactNode
}

export default function SeoText({ children }: SeoTextProps) {
  return <div className="prose max-w-none text-sm text-gray-600">{children}</div>
}

