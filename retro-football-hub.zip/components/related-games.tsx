import Image from "next/image"
import Link from "next/link"

interface RelatedGame {
  title: string
  slug: string
  imageUrl: string
}

interface RelatedGamesProps {
  currentGame?: string
  title?: string
}

export default function RelatedGames({ currentGame, title = "More Games You Might Like" }: RelatedGamesProps) {
  const allGames: RelatedGame[] = [
    {
      title: "Retro Bowl",
      slug: "retro-bowl",
      imageUrl: "/game-retro-bowl.jpg",
    },
    {
      title: "Retro Bowl 2",
      slug: "retro-bowl-2",
      imageUrl: "/game-retro-bowl-2.jpg",
    },
    {
      title: "Retro Bowl 25",
      slug: "retro-bowl-25",
      imageUrl: "/game-retro-bowl-25.jpg",
    },
    {
      title: "Retro Football",
      slug: "retro-football",
      imageUrl: "/game-retro-football.jpg",
    },
    {
      title: "Football Stars",
      slug: "football-stars",
      imageUrl: "/game-football-stars.jpg",
    },
    {
      title: "Touchdown Pro",
      slug: "touchdown-pro",
      imageUrl: "/game-touchdown-pro.jpg",
    },
    {
      title: "Pixel Football",
      slug: "pixel-football",
      imageUrl: "/game-pixel-football.jpg",
    },
    {
      title: "Football Legends",
      slug: "football-legends",
      imageUrl: "/game-football-legends.jpg",
    },
  ]

  // Filter out the current game if provided
  const filteredGames = currentGame ? allGames.filter((game) => game.slug !== currentGame) : allGames

  // Take up to 6 games
  const gamesToShow = filteredGames.slice(0, 6)

  return (
    <div className="related-games">
      <h3 className="related-games-title">{title}</h3>
      <div className="related-games-list">
        {gamesToShow.map((game) => (
          <Link key={game.slug} href={`/play/${game.slug}`} className="related-game-item">
            <Image
              src={game.imageUrl || "/placeholder.svg"}
              alt={game.title}
              width={64}
              height={64}
              className="related-game-image"
            />
            <span className="related-game-name">{game.title}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

