export default function AdSidebar() {
  return (
    <div className="hidden lg:block">
      <div className="sticky top-24">
        <ins
          className="adsbygoogle"
          style={{ display: "inline-block", width: "300px", height: "250px" }}
          data-ad-client="ca-pub-xxx"
          data-ad-slot="xxx"
        ></ins>
        <script
          dangerouslySetInnerHTML={{
            __html: `
          (adsbygoogle = window.adsbygoogle || []).push({});
        `,
          }}
        />
      </div>
    </div>
  )
}

