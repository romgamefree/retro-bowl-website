"use client"

import Link from "next/link"
import { Menu, X } from "lucide-react"
import { useState, useEffect } from "react"
import Image from "next/image"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${isScrolled ? "bg-white shadow-md" : "bg-white/80 backdrop-blur-md"}`}
    >
      <div className="container-custom">
        <div className="flex h-14 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Image src="/logo.png" alt="Retro Bowl Hub" width={32} height={32} className="h-8 w-8" />
            <span className="font-heading text-lg font-bold text-primary">RetroFootballHub</span>
          </Link>

          <button
            className="inline-flex items-center justify-center rounded-md p-2 text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <span className="sr-only">Open main menu</span>
            {isMenuOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>

          <nav className="hidden md:flex md:space-x-6">
            <Link href="/" className="text-sm font-medium text-gray-700 hover:text-primary">
              Home
            </Link>
            <Link href="/play/retro-bowl" className="text-sm font-medium text-gray-700 hover:text-primary">
              Play Now
            </Link>
            <Link href="/tips" className="text-sm font-medium text-gray-700 hover:text-primary">
              Tips
            </Link>
            <Link href="/leaderboards" className="text-sm font-medium text-gray-700 hover:text-primary">
              Leaderboards
            </Link>
            <Link href="/community" className="text-sm font-medium text-gray-700 hover:text-primary">
              Community
            </Link>
            <Link href="/about" className="text-sm font-medium text-gray-700 hover:text-primary">
              About
            </Link>
          </nav>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2">
              <Link
                href="/"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/play/retro-bowl"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Play Now
              </Link>
              <Link
                href="/tips"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Tips
              </Link>
              <Link
                href="/leaderboards"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Leaderboards
              </Link>
              <Link
                href="/community"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Community
              </Link>
              <Link
                href="/about"
                className="block rounded-md px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Smaller Header Banner Ad */}
      <div className="adsense-container py-1">
        <ins
          className="adsbygoogle"
          style={{ display: "inline-block", width: "100%", maxWidth: "728px", height: "60px" }}
          data-ad-client="ca-pub-xxx"
          data-ad-slot="xxx"
        ></ins>
        <script
          dangerouslySetInnerHTML={{
            __html: `
          (adsbygoogle = window.adsbygoogle || []).push({});
        `,
          }}
        />
      </div>
    </header>
  )
}

